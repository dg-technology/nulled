package com.oxoo.spagreen.listener;

public interface OnItemClickLIstener {
        void onItemClick(int position);
    }