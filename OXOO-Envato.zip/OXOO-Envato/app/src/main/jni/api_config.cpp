#include <jni.h>
#include <string>


//std::string SERVER_URL = "http://demo.redtvlive.com/oxoo/v13/rest-api/";
std::string SERVER_URL = "https://app.codecanvas.xyz/hexa_admin/rest-api/";
//std::string API_KEY = "6rzjknrcnzyr93tm5xgyrq3j";
std::string API_KEY = "d9c9e65915450e814bfe2efe";
std::string PURCHASE_CODE = "77b3e620-ebb0-4e45-b6cb-525b3a340207";
std::string YOUTUBE_API_KEY = "AIzaSyBURBj1a4kTjmOJzaZ3naLOJ7x66vEb_KI";

extern "C" JNIEXPORT jstring JNICALL
// Change "com_oxoo_spagreen" with your package name. // I.e "com_package_name" // DO NOT CHANGE OTHER THINGS
Java_com_oxoo_spagreen_AppConfig_getApiServerUrl(
        JNIEnv* env,
        jclass clazz) {
    return env->NewStringUTF(SERVER_URL.c_str());
}

extern "C" JNIEXPORT jstring JNICALL
// Change "com_oxoo_spagreen" with your package name. // I.e "com_package_name" // DO NOT CHANGE OTHER THINGS

Java_com_oxoo_spagreen_AppConfig_getApiKey(
        JNIEnv* env,
jclass clazz) {
return env->NewStringUTF(API_KEY.c_str());
}

extern "C" JNIEXPORT jstring JNICALL
// Change "com_oxoo_spagreen" with your package name. // I.e "com_package_name" // DO NOT CHANGE OTHER THINGS

Java_com_oxoo_spagreen_AppConfig_getPurchaseCode(
        JNIEnv* env,
        jclass clazz) {
    return env->NewStringUTF(PURCHASE_CODE.c_str());
}

extern "C" JNIEXPORT jstring JNICALL
// Change "com_oxoo_spagreen" with your package name. // I.e "com_package_name" // DO NOT CHANGE OTHER THINGS

Java_com_oxoo_spagreen_AppConfig_getYouTubeApiKey(
        JNIEnv* env,
        jclass clazz) {
    return env->NewStringUTF(YOUTUBE_API_KEY.c_str());
}
